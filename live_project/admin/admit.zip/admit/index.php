<?php
 print "<script>location='../../../'</script>";
?>